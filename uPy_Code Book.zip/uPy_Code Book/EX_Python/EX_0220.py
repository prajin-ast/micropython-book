"""
EX_0220 (Python Membership operators)
Basic Python programming by appsofttech.com
"""
# Membership operators: in, not in

a = ["Programming", "Python"]
b = "Programming"
c = "Prog"

print(b in a)
print(c in a)
print("python" in a)
print("Python" in a)
print("python" not in a)
print(c in b)
print("Pr" in b)
