"""
EX_0401(Python functions)
Basic Python programming by appsofttech.com
"""
# function

def play():
    print("Python Programming")

play()
print('...')
