"""
EX_0208 (Python List)
Basic Python programming by appsofttech.com
"""
# Copy List

a = [2020, 2021, 2022, 2023]
b = ['a', 'b', 'ab', 'ba']

print('list a:', a)
c = a.copy()
print('list c:', c)
d = list(a)
print('list d:', d)
