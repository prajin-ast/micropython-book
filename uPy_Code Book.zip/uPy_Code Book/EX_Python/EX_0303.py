"""
EX_0303 (Python if..elif..else..)
Basic Python programming by appsofttech.com
"""
# if..elif..else statement (Python Conditions)

a = 300
b = 200

if a < b:
    print("b > a")
elif a > b:
    print("a < b")
else:
    print("a = b")

print('...')
