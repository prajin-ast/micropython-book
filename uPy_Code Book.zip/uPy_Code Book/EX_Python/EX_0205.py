"""
EX_0205 (Python String)
Basic Python programming by appsofttech.com
"""

a = 'Basic Python Programming'
b = 'by appsofttech.com'

print(a + ' is Easy!')
print(b*2)

