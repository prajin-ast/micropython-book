"""
EX_0329 (Python pass)
Basic Python programming by appsofttech.com
"""
# pass

a = 0

while a < 5:
    a += 1
    pass
    print(a)

print('...')
