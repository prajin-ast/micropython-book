"""
EX_0216 (Python Arithmetic & Assignment operators)
Basic Python programming by appsofttech.com
"""
# Arithmetic operators: +, -, *, /, %, **, //
# & Assignment operators: =

a = 13
b = 3

print("a+b = ", a+b)
print("a-b = ", a-b)
print("a*b = ", a*b)
print("a/b = ", a/b)
print("a%b = ", a%b)        # **
print("a**b = ", a**b)
print("a//b = ", a//b)

