"""
EX_0206 (Python List)
Basic Python programming by appsofttech.com
"""
# Access Items in List

a = [2020, 2021, 2022, 2023]
b = ['a', 'b', 'ab', 'ba']

print('list a:', a)
print('list b:', b)
print(a[0])
print(b[3])
print(a[-1])
print(a[0:3])
