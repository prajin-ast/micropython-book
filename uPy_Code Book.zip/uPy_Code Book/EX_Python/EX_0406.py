"""
EX_0406 (Python import)
Basic Python programming by appsofttech.com
"""
# import statement

import math

a = 10

print("a:", a)
print("sin a:", math.sin(a))
print('...')
