"""
EX_0304 (Python for..)
Basic Python programming by appsofttech.com
"""
# for (Python Loops)

for i in range(0,10,1):
    print(i)

print('...')
