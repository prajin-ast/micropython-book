"""
EX_0410 (Python String format())
Basic Python programming by appsofttech.com
"""
# String format()

a = 10
b = 20
c = 30
num = "a: {} b: {} c: {:.2f}"
print(num.format(a, b, c))

print('...')
