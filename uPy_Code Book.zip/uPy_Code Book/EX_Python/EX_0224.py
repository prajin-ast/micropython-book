"""
EX_0224 (Python Collections (Arrays))
Basic Python programming by appsofttech.com
"""
# Collections (Arrays)

mySet = {1, 2, 3}

print(type(mySet))
print(mySet)
print(len(mySet))

print(1 in mySet)
print(5 in mySet)

for ms in mySet:
    print(ms)





