"""
EX_0207 (Python List)
Basic Python programming by appsofttech.com
"""
# Change/Adds/Remove Item in List

a = [2020, 2021, 2022, 2023]
b = ['a', 'b', 'ab', 'ba']

print('list a:', a)
a[0] = 2024
print('list a:', a)
a.append(2025)
print('list a:', a)
a.remove(2025)
print('list a:', a)
