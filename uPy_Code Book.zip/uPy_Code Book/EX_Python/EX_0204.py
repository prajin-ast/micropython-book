"""
EX_0204 (Python String)
Basic Python programming by appsofttech.com
"""

a = 'Basic Python Programming'
b = 'by appsofttech.com'

print(a[0])     # Slicing
print(a[0:5])
print(b[0:])
print(b[:3])
