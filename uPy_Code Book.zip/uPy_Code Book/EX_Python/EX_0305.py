"""
EX_0305 (Python for..)
Basic Python programming by appsofttech.com
"""
# for (Python Loops)

for i in range(10,0,-1):
    print(i)

print('...')
