"""
EX_0301 (Python if..)
Basic Python programming by appsofttech.com
"""
# if.. statement (Python Conditions)

a = 300
b = 200

if a < b:
    print("a < b")

print('...')
