"""
EX_0307 (Python break)
Basic Python programming by appsofttech.com
"""
# break

a = 0

while a < 10:
    a += 1
    if a > 5:
        break
    print(a)

print('...')
