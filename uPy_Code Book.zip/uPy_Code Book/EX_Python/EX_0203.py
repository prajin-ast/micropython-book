"""
EX_0203 (Python String)
Basic Python programming by appsofttech.com
"""

a = 'Basic Python Programming'
b = 'by appsofttech.com'

print("String :", a, b)
