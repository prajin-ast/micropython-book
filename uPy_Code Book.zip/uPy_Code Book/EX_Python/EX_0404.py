"""
EX_0404 (Python module)
Basic Python programming by appsofttech.com
"""
# module

def inc_num(a):
    a = a + 1
    return a

def add_num(a, b):
    return a + b
