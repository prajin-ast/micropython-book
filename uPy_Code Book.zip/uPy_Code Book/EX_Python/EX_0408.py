"""
EX_0408 (Python import all)
Basic Python programming by appsofttech.com
"""
# from..import * statement

from math import *

a = 10

print("a:", a)
print("sin a:", sin(a))
print("pi:", pi)
print('...')
