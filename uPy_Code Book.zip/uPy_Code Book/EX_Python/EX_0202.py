"""
EX_0202 (Python Numbers)
Basic Python programming by appsofttech.com
"""

a = 1+2j
b = 3.4j
c = -1+4j

print("Complex Number:", a, b, c)
