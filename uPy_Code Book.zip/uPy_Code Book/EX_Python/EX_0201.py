"""
EX_0201 (Python Numbers)
Basic Python programming by appsofttech.com
"""

a = 20
b = -20
c = 20.20
d = -20.20

print("Number:", a, b, c, d)
