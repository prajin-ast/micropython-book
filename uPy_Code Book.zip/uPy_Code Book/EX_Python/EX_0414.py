"""
EX_0414 (Python Exceptions)
Basic Python programming by appsofttech.com
"""
# try... except

a = 10
b = 0

try:
    print('a/b:', a/b)
except:
    print('division by zero')

print('....')
