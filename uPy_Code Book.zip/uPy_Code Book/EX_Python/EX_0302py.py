"""
EX_0302 (Python if..else..)
Basic Python programming by appsofttech.com
"""
# if..else statement (Python Conditions)

a = 300
b = 200

if a < b:
    print("a < b")
else:
    print("a > b")

print('...')
