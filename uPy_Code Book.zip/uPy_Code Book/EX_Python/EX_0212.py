"""
EX_0212 (Python Variables)
Basic Python programming by appsofttech.com
"""
# Global Variables

a = "a is global"

def my_func():
    print("a (in my_func) :", a)

my_func()
print("a (main) :", a)
