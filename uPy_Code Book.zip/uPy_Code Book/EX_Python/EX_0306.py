"""
EX_0306 (Python while)
Basic Python programming by appsofttech.com
"""
# while (Python Loops)

a = 0

while a < 10:
    print(a)
    a += 1

print('...')
