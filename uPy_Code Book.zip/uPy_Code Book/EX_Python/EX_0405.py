"""
EX_0405 (Python module)
Basic Python programming by appsofttech.com
"""
# call module "EX_0404"

import EX_0404 as num

a = 10
b = 10

c = num.add_num(a, b)
print("c:", c)
c = num.inc_num(c)
print("c:", c)
