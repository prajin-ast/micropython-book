"""
EX_0 (Python functions)
Basic Python programming by appsofttech.com
"""
# function

def play(a):
    print("function play")
    print(a)

def add(a, b):
    print("function add")
    return a + b

a = add(10, 10)
play(a)
print('...')
