"""
EX_0217 (Python Comparison operators)
Basic Python programming by appsofttech.com
"""
# Comparison operators: ==, !=, >, <, >=, <=

a = 10
b = 5

print("a == b is", a==b)
print("a != b is", a!=b)
print("a > b  is", a>b)
print("a < b  is", a<b)
print("a >= b is", a>=b)
print("a <= b is", a<=b)

