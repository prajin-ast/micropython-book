"""
EX_0215 (Python Variables)
Basic Python programming by appsofttech.com
"""
# Assigning a value

a = 10         # a is of type Integer
b = "Python"   # b is of type String
c = 99.9       # c is of type Float

x, y, z = "Python", "Computer", 2020

print(a)
print(b)
print(c)

print(a, b, c)
print(x, y, z)
print(".........")
print("a is ", type(a))
print("b is ", type(b))
print("c is ", type(c))
