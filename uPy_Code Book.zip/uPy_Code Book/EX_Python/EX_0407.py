"""
EX_00407 (Python from.. import)
Basic Python programming by appsofttech.com
"""
# from..import statement

from math import sin

a = 10

print("a:", a)
print("sin a:", sin(a))
print('...')
