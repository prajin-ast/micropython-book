# ----------------------------------------
# main.py
# MicroPython book by AppSoftTech
# ----------------------------------------
# this is the main script that will contain your Python program.
# It is executed after boot.py.

# chang file name for run auto
exec(open('./LAB_2001.py').read(),globals())
